import type * as Grunt from 'grunt';
import type { WebpackPluginInstance } from 'webpack';

import _ from 'lodash';
import TerserPlugin from 'terser-webpack-plugin';
import loadGruntTasks from 'load-grunt-tasks';
import browserConfig from './build/browser.ts';
import moduleConfig from './build/module.ts';
import serverConfig from './build/server.ts';

const serverConfigs = {
	browser: browserConfig,
	module: moduleConfig,
	server: serverConfig,
};

for (const config of Object.values(serverConfigs)) {
	config.optimization = {
		minimizer: [
			new TerserPlugin({
				parallel: true,
				terserOptions: {
					output: {
						beautify: true,
						ascii_only: true,
					},
					compress: {
						sequences: false,
						unused: false, // We need this off for OMeta
					},
					mangle: false,
				},
			}),
		],
	};
}

const gruntfile = (grunt: typeof Grunt) => {
	grunt.initConfig({
		clean: {
			default: {
				src: [`<%= grunt.option('target') %>`],
				options: {
					force: true,
				},
			},
		},

		checkDependencies: {
			this: {
				options: {
					packageManager: 'npm',
					// TODO: Enable when grunt-check-dependencies works correctly with deduped packages.
					// onlySpecified: true
				},
			},
		},

		concat: _.mapValues(serverConfigs, (config, task) => {
			const defines = (
				config.plugins as Array<
					WebpackPluginInstance & { definitions?: object }
				>
			).find((plugin) => plugin.definitions != null)!.definitions;
			return {
				options: {
					banner: `
							/*! Build: ${task} - <%= grunt.option('version') %>
							Defines: ${JSON.stringify(defines, null, '\t')}
							*/
						`,
				},
				src: ['out/pine.js'],
				dest: 'out/pine.js',
			};
		}),

		copy: {
			default: {
				files: [
					{
						expand: true,
						cwd: 'src',
						src: ['**'],
						dest: `<%= grunt.option('target') %>`,
						filter: (filename: string) =>
							filename.endsWith('.d.ts') || !filename.endsWith('.ts'),
					},
				],
			},
		},

		gitinfo: {
			commands: {
				describe: ['describe', '--tags', '--always', '--long', '--dirty'],
			},
		},

		rename: (() => {
			const renames: Record<string, { src: string; dest: string }> = {};
			for (const task of Object.keys(serverConfigs)) {
				renames[task] = {
					src: 'out/pine.js',
					dest: `out/pine-${task}-<%= grunt.option('version') %>.js`,
				};
				renames[`${task}.map`] = {
					src: 'out/pine.js.map',
					dest: `out/pine-${task}-<%= grunt.option('version') %>.js.map`,
				};
			}
			return renames;
		})(),

		replace: _.mapValues(serverConfigs, (_config, task) => {
			return {
				src: 'out/pine.js',
				overwrite: true,
				replacements: [
					{
						from: /sourceMappingURL=pine.js.map/g,
						to: `sourceMappingURL=pine-${task}-<%= grunt.option('version') %>.js.map`,
					},
				],
			};
		}),

		webpack: serverConfigs,

		ts: {
			default: {
				tsconfig: {
					passThrough: true,
				},
				options: {
					additionalFlags: `--outDir <%= grunt.option('target') %>`,
				},
			},
		},
	});

	loadGruntTasks(grunt);

	if (!grunt.option('target')) {
		grunt.option('target', 'out/');
	}

	grunt.registerTask('version', function () {
		this.requires('gitinfo:describe');
		grunt.option('version', grunt.config.get('gitinfo.describe'));
	});

	for (const task of Object.keys(serverConfigs)) {
		grunt.registerTask(task, [
			'checkDependencies',
			'webpack:' + task,
			'gitinfo:describe',
			'version',
			`replace:${task}`,
			`concat:${task}`,
			`rename:${task}`,
			`rename:${task}.map`,
		]);
	}

	grunt.registerTask('build', ['clean', 'checkDependencies', 'ts', 'copy']);
};

// Grunt loads the gruntfile via `require`, so expose the function as `module.exports`
export { gruntfile as 'module.exports' };

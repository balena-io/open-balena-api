// EXPERIMENT: counters to measure the cost of the per permission list caches
export const experimentStats = {
	constrainedModelLookups: 0,
	constrainedModelBuilds: 0,
	constrainedModelBuildMs: 0,
	constrainedTableDefinitions: 0,
	constrainedTableDefinitionMs: 0,
	odataToAbstractSqlMisses: 0,
	odataToAbstractSqlMs: 0,
};

export const timed = <Args extends any[], R>(
	countKey: keyof typeof experimentStats,
	msKey: keyof typeof experimentStats,
	fn: (...args: Args) => R,
) => {
	const wrapped = function (this: any, ...args: Args): R {
		const start = performance.now();
		try {
			return fn.apply(this, args);
		} finally {
			experimentStats[countKey]++;
			experimentStats[msKey] += performance.now() - start;
		}
	};
	// memoizee keys on `fn.length` arguments, so the wrapper must keep the original arity
	// or every call would share a single cache entry
	Object.defineProperty(wrapped, 'length', { value: fn.length });
	return wrapped;
};
